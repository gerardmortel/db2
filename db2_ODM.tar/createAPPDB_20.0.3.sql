create database APPDB automatic storage yes using codeset UTF-8 territory US pagesize 32768;

-- connect to the created database:
connect to APPDB;

-- Create bufferpool and tablespaces
CREATE BUFFERPOOL DBASBBP IMMEDIATE SIZE 1024 PAGESIZE 32K;
CREATE REGULAR TABLESPACE APPENG_TS PAGESIZE 32 K MANAGED BY AUTOMATIC STORAGE DROPPED TABLE RECOVERY ON BUFFERPOOL DBASBBP;
CREATE USER TEMPORARY TABLESPACE APPENG_TEMP_TS PAGESIZE 32 K MANAGED BY AUTOMATIC STORAGE BUFFERPOOL DBASBBP;

-- grant access rights to the tablespaces
GRANT USE OF TABLESPACE APPENG_TS TO user db2inst1;
GRANT USE OF TABLESPACE APPENG_TEMP_TS TO user db2inst1;

-- The following grant is used for databases without enhanced security.
-- For more information, review the IBM documentation for enhancing security for DB2.
grant dbadm on database to user db2inst1;

connect reset;

