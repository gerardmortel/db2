#!/bin/bash

db2 drop database ICNDB
db2 drop database GCDDB
db2 drop database OS1DB
db2 drop database BAWDOCS
db2 drop database BAWDOS
db2 drop database BAWTOS
db2 drop database AEOSDB
db2 drop database AAEDB
db2 drop database APPDB
db2 drop database UMSDB
db2 drop database BAWAUDB
db2 drop database BPMDB
#db2 drop database BASDB

./createICNDB.sh ICNDB db2inst1
./createGCD_V115.sh GCDDB db2inst1
./createOSDB_V115.sh OS1DB db2inst1
./createOSDB_V115.sh BAWDOCS db2inst1
./createOSDB_V115.sh BAWDOS db2inst1
./createOSDB_V115.sh BAWTOS db2inst1
./createOSDB_V115.sh AEOSDB db2inst1
db2 -tvf createAAEDB_20.0.3.sql
db2 -tvf createAPPDB_20.0.3.sql
db2 -tvf createUMSDB.sql
db2 -tvf createBAWAUDB.sql
db2 -tvf createBPMDB.sql
#db2 -tvf createBASDB.sql