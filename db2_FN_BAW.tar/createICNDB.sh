#!/usr/bin/env bash

if [ $# -eq 0 ]
then
  echo
  echo  Usage: $0 "<name for database (must be 8 characters long or less) > <instance_name> "
  echo
  exit 1
fi

arg1=$1

len=${#arg1}
if [ $len -gt 8 ]
then
  echo
  echo Invalid DB name "$arg1" : Must be 8 characters or less.
  echo DB creation would fail.  Exiting...
  echo
  exit 1
fi


dbname=$1
dbuser=$2


echo "*** Creating DB named: ${dbname} ***"

db2 create database "${dbname}" automatic storage yes using codeset UTF-8 territory US pagesize 32 K
db2 connect to "${dbname}";
db2 grant dbadm on database to user "${dbuser}";
db2 connect reset;

